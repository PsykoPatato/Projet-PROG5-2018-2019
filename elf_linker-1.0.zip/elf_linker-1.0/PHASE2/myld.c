#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <fcntl.h>
#include <elf.h>
#include <getopt.h>
#include "header.h"
#include "section.h"
#include "contenuS.h"
#include "symbole.h"
#include "relocation.h"
#include "RenumSec.h"
#include "renumSymb.h"

Elf32_Sym *symb;
char *nomSym;
Elf32_Shdr *nshdr;

void help(){
  printf("Saisir:\n nomSection + addresse_de _chargement + nom_prog + fichier\n");
}

int main(int argc, char **argv){
   FILE *f, *ficout;
   int i;
   if(argc < 3 ){
     help();
     exit(1);
   }

//------------Etape 3: recup du num/nom de section-------------------------------------------------------


//----------Recup du fichier-----------------------
   //printf("%s\n", argv[argc-1]);
  f = fopen(argv[argc-1], "r");
  // assert(f != NULL);
   if(f == NULL){
      printf("erreur d'ouverture du fichier!\n" );
   }
   ficout = fopen(argv[argc-2], "w");
   assert(ficout != NULL);

//------------------------------------------
   Elf32_Ehdr *ehdr = malloc(sizeof(Elf32_Ehdr));
   assert(ehdr != NULL);


   readHeader(f, ehdr);

   Elf32_Shdr *shdr = malloc(sizeof(Elf32_Shdr) *ehdr->e_shnum);
   assert(shdr != NULL);

   readSection(f, ehdr, shdr);


//-------------------------Etape 2---------------------------------
  //recup du tableau des noms de sections
  int t = shdr[ehdr->e_shstrndx].sh_size;
  char *nom = malloc(t);
  assert(nom != NULL);

  fseek(f, shdr[ehdr->e_shstrndx].sh_offset, SEEK_SET);
  fread(nom, t, 1, f);


 //-------Etape 4:--creation table de symboles--------------------------------------------------------------
   //recherche de l'indice de ".symtab" dans la table des sections
   int iSym; //indice de .SYMTAB
   int taille; //taille de la table de symboles
   i = 0;
   while(i < ehdr->e_shnum  &&  shdr[i].sh_type != 2){
     i++;
   }
   if(i == ehdr->e_shnum){
     printf("indice de « .symtab » non trouvé!\n");
     iSym = 0;
     //exit(4);
   }
   else{
     iSym = i;
   }

   //--------------copie des NOMs de Symboles-----------------------------
   //recherche de l'indice de ".strtab" dans la table des sections
   int id; //indice de .STRTAB
   i = 0;
    while (i < ehdr->e_shnum && strcmp(".strtab", nom+shdr[i].sh_name)) {
     i++;
   }
   if(i == ehdr->e_shnum){
     printf("indice de « .strtab » non trouvé!\n");
     id = 0;
     //exit(4);
   }
   else{
     id = i; //printf("%d\t", id);
   }

     int k = shdr[id].sh_size;
     nomSym  = malloc(k);
     assert(nomSym != NULL);
     fseek(f, shdr[id].sh_offset, SEEK_SET);
     fread(nomSym, k, 1, f);
     //printf("%s\n", nom+shdr[sym].sh_name);


   taille = shdr[iSym].sh_size / shdr[iSym].sh_entsize;
   symb = malloc(sizeof(Elf32_Sym) * taille);
   assert(symb != NULL);
   //test(taille);
   readSymbole(f, ehdr, shdr, symb, iSym);

   //----------------------------------------------------------

   //---------------Etape 6--------------------------------------------------------

     i=0, k = 0; //le nouveau nbre de sections
     while(i < ehdr->e_shnum){
         if(shdr[i].sh_type != SHT_REL && shdr[i].sh_type != SHT_RELA){ //SHT_REL
          k++;
        }
       i++;
     }

     //nshdr devient la nouvelle table header section, de sorte que chaque section devient numérotée
     nshdr = malloc(sizeof(Elf32_Shdr) * k);
     assert(nshdr != NULL );
     ecriture(f, ficout, ehdr, shdr, nshdr, nom);
     //----------------------Etape 7-----------------------------------------
      change(ehdr, shdr, nshdr, symb, taille, k);

      int value;
      for(i=1; i<argc-1; i++){
        int indS = estSection(nshdr, k, argv[i], nom);
        if(indS > 0){
         printf("valeur de chargement de %s prise en compte!\n", argv[i]);
         value = atoi(argv[i+1]);
         fillValue(symb, taille, indS,  value);
        }
      }
      //--------une fois symb modifiée, faudra la recopier dans ficout------
      int indSymt = estSection(nshdr, k, ".symtab", nom);
      //printf("ind:%d  offset de .symtab:%x\n", indSymt, shdr[indSymt].sh_offset);
      fseek(ficout, shdr[indSymt].sh_offset, SEEK_SET);
      fwrite(symb, taille, 1, ficout);


//------------------------------------------------------------------------------------


  fclose(ficout);
  fclose(f);
  free(nom);
  free(ehdr);
  free(shdr);
  free(nshdr);
  free(symb);
  free(nomSym);

  return 0;
}
