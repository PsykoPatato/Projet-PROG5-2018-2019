#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <elf.h>
#include "RenumSec.h"
#include "renumSymb.h"


void copie(FILE *f, void *t, int k){
  int i, ind=0;
  char b1[k], b2[k];

  for(i=0; i<k; i++){
    b1[i] = *((char *)t++);
  }

    for(i=k-1; i>=0; i--){
      b2[ind] = b1[i];
      ind++;
    }
    fwrite(b2, k, 1, f);
}

//lecture header et sections(sauf celles de type Rel) dans ficin et copie dans ficout
void ecriture(FILE *f, FILE *ficout, Elf32_Ehdr *ehdr, Elf32_Shdr * shdr, Elf32_Shdr *nshdr, char *nom){
  //------Renumérotation des sections: calcul du nbre de sections et de leur taille---------------------
  //--------------------et MSJ des offsets------------------------------
  int i;


  //------------------------------------------------------------
  int k=0; //le nouveau nbre de sections
  unsigned offset = ehdr->e_phoff + ehdr->e_ehsize;      //offset
  int ind=0;
  i=0;
  while(i < ehdr->e_shnum){
      if(shdr[i].sh_type != SHT_REL && shdr[i].sh_type != SHT_RELA){
       k++;

       nshdr[ind] = shdr[i];
       ind++;

       shdr[i].sh_offset = offset;
       offset += shdr[i].sh_size;
     }
     i++;
  }
  ehdr->e_shoff = offset;
  int ind1 = estSection(nshdr, k, ".shstrtab", nom);
  ehdr->e_type = 2;

  //-------------------- ecriture tete--------------------------------------------------------
  fwrite(ehdr->e_ident, EI_NIDENT, 1, ficout);
  copie(ficout, &ehdr->e_type, sizeof(ehdr->e_type));
  copie(ficout, &ehdr->e_machine, sizeof(ehdr->e_machine));
  copie(ficout, &ehdr->e_version, sizeof(ehdr->e_version));
  copie(ficout, &ehdr->e_entry, sizeof(ehdr->e_entry));
  copie(ficout, &ehdr->e_phoff, sizeof(ehdr->e_phoff));
  copie(ficout, &ehdr->e_shoff, sizeof(ehdr->e_shoff));
  copie(ficout, &ehdr->e_flags, sizeof(ehdr->e_flags));
  copie(ficout, &ehdr->e_ehsize, sizeof(ehdr->e_ehsize));
  copie(ficout, &ehdr->e_phentsize, sizeof(ehdr->e_phentsize));
  copie(ficout, &ehdr->e_phnum, sizeof(ehdr->e_phnum));
  copie(ficout, &ehdr->e_shentsize, sizeof(ehdr->e_shentsize));
  copie(ficout, &k, sizeof(ehdr->e_shnum));                    //le nouveau nbre de sections
  copie(ficout, &ind1, sizeof(ehdr->e_shstrndx));
//---------------------------------------------------------------------------------------

  //fread(ficout, sizeof(Elf32_Ehdr), 1, f);
  //----------------------ecriture des sections non Rel ou Rela -------------------
  for(int ind=0; ind<ehdr->e_shnum; ind++){
    if(shdr[ind].sh_type != SHT_REL && shdr[ind].sh_type != SHT_RELA){
      fseek(f, shdr[ind].sh_offset, SEEK_SET); //on se place au debut de la section à lire

      char *buf =  malloc(shdr[ind].sh_size);
      assert(buf != NULL);

      fread(buf, shdr[ind].sh_size, 1, f);

      fwrite(buf, shdr[ind].sh_size, 1, ficout);
      //printf("section ecrite!\n" );
      free(buf);
    }
  }

  //------------------Renumérotation des sections (copie de la table d'entete de sections)-------------------------------
  //descendre du nouvel offset, et copie de chaque entrée de la table de section header
  fseek(ficout, ehdr->e_shoff, SEEK_SET);
  for(int i=0; i<k; i++){
    //if(shdr[i].sh_type != SHT_REL && shdr[i].sh_type != SHT_RELA){

        copie(ficout, &nshdr[i].sh_name, sizeof(nshdr[i].sh_name));
        copie(ficout, &nshdr[i].sh_type, sizeof(nshdr[i].sh_type));
        copie(ficout, &nshdr[i].sh_flags, sizeof(nshdr[i].sh_flags));
        copie(ficout, &nshdr[i].sh_addr, sizeof(nshdr[i].sh_addr));
        copie(ficout, &nshdr[i].sh_offset, sizeof(nshdr[i].sh_offset));
        copie(ficout, &nshdr[i].sh_size, sizeof(nshdr[i].sh_size));
        copie(ficout, &nshdr[i].sh_link, sizeof(nshdr[i].sh_link));
        copie(ficout, &nshdr[i].sh_info, sizeof(nshdr[i].sh_info));
        copie(ficout, &nshdr[i].sh_addralign, sizeof(nshdr[i].sh_addralign));
        copie(ficout, &nshdr[i].sh_entsize, sizeof(nshdr[i].sh_entsize));

    //}

  }

}
