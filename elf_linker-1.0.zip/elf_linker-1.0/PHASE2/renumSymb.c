#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <elf.h>
#include "renumSymb.h"

//Parcours de la table de Symboles et Corrections des indices de Section(symb[i].st_shndx)
void change(Elf32_Ehdr *ehdr, Elf32_Shdr *shdr, Elf32_Shdr *nshdr, Elf32_Sym *symb, int tailleSymb, int tailleNSHDR){
  int i;
  //parcours de la table de Symboles et, recherche de l'indice de section correspondant pr chacun

  for(int ind=0; ind<tailleSymb; ind++){
    i = 0;
    while(i < tailleNSHDR  &&  nshdr[i].sh_name != shdr[ symb[ind].st_shndx ].sh_name ){
      i++;
    }
    if(i == tailleNSHDR){
      printf("indice de Section correspondant non trouvé!\n");
      symb[ind].st_shndx = 0;
    }
    else{
      symb[ind].st_shndx = i;
    }

  }
}

//ex: myld .text 58   ?ts les symb associés à .texte recoivent 58 comme value?
//Parcours des arguments et si estSection(argv[i]), alors argv[i+1] est l'addresse de chargement de la section argv[i]
void fillValue(Elf32_Sym *symb, int tailleSymb, int indS, unsigned value){
  int i;
  for(i=0; i<tailleSymb; i++){
    if(symb[i].st_shndx == indS){
      symb[i].st_value = value;
      printf("val modified!\n");
    }
  }

}

/*retourne un indice de section si s est un nom de section valide et -1 sinon*/
int estSection(Elf32_Shdr *nshdr, int tailleNSHDR, char *s, char *nom){
  int res, i = 0;
  //printf("arg:%s\n",s );
  while(i < tailleNSHDR  &&  strcmp(s, (nom+nshdr[i].sh_name) ) ){
    i++;
  }
  if(i == tailleNSHDR){
    //printf("nom de section invalide!\n");
    res = -1;
  }
  else{
    res = i;
  }
  return res;
}
