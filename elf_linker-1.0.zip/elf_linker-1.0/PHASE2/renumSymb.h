#ifndef __RenumSymb_H__
#define __RenumSymb_H__

int estSection(Elf32_Shdr *nshdr, int tailleNSHDR, char *s, char *nom);

void fillValue(Elf32_Sym *symb, int tailleSymb, int indS, unsigned value);

void change(Elf32_Ehdr *ehdr, Elf32_Shdr * shdr, Elf32_Shdr *nshdr, Elf32_Sym *symb, int tailleSymb, int tailleNSHDR);



#endif
