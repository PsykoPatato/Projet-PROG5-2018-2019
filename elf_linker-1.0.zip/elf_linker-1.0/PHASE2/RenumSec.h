#ifndef __RenumSec_H__
#define __RenumSec_H__


void ecriture(FILE *f, FILE *ficout, Elf32_Ehdr *ehdr, Elf32_Shdr * shdr, Elf32_Shdr *nshdr, char *nom);

//void change(FILE *f, Elf32_Ehdr *ehdr, Elf32_Shdr * shdr, Elf32_Sym *symb);


#endif
