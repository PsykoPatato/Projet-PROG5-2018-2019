#ifndef __ContenuS_H__
#define __ContenuS_H__

void contenuS(FILE *f, Elf32_Ehdr *ehdr, Elf32_Shdr *shdr, int ind, char *nom);


#endif
