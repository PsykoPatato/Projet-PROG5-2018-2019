#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <fcntl.h>
#include <elf.h>
#include <getopt.h>
#include "header.h"
#include "section.h"
#include "contenuS.h"
#include "symbole.h"
#include "relocation.h"




void help(){
  printf("Saisir option + nom de fichier:\n\
               -h: affichage du Header \n\
               -S: affichage de la table des sections\n\
               -x: suivi de num/nom de section pour afficher le contenu d'une section\n\
               -s: affichage de la table des symboles\n\
               -r: affichage des tables de réimplantation\n\
               -a: (--all).\n");
}

int main(int argc, char **argv){
   int c;
   Elf32_Sym *symb;
   char *nomSym;
   char *section;
   int i, v;
   int ind;
   char *nomS; //nom de la section à afficher
   FILE *f;
   if(argc < 3 && strcmp(argv[1], "-H") ){
     help();
     exit(1);
   }
//--------------//recup de l'option i pour etape i---------------------------------------------------
int opt;

struct option longopts[] = {
{ "header", required_argument, NULL, 'h' },
{ "Section", required_argument, NULL, 'S' },
{ "Contenu", required_argument, NULL, 'x' }, //2 arguments
{ "Symbole", required_argument, NULL, 's' },
{ "relocation", required_argument, NULL, 'r' },
{ "all", required_argument, NULL, 'a' },
{ "help", no_argument, NULL, 'H' },
{ NULL, 0, NULL, 0 }
};


//-------------------------------------------------------------------------------
  while ((opt = getopt_long(argc, argv, "x:s:r:a:S:H:h", longopts, NULL)) != -1) {
  switch(opt) {
  case 'H':
   help();
   break;
  case 'h':
   c = 1;
   break;
  case 'S':
   c = 2;
  case 'x':
    c = 3;
   break;
  case 's':
   c = 4;
   break;
  case 'r':
    c = 5;
   break;
  case 'a':
    c = 6;
    break;

  default:
   fprintf(stderr, "Unrecognized option %c\n", opt);
   help();
   exit(1);
  }
  }
//------------Etape 3: recup du num/nom de section-------------------------------------------------------


//----------Recup du fichier-----------------------
   //printf("%s\n", argv[argc-1]);
  f = fopen(argv[argc-1], "r");
  // assert(f != NULL);
   if(f == NULL){
      printf("erreur d'ouverture du fichier!\n" );
   }


//------------------------------------------
   Elf32_Ehdr *ehdr = malloc(sizeof(Elf32_Ehdr));
   assert(ehdr != NULL);


   readHeader(f, ehdr);

   Elf32_Shdr *shdr = malloc(sizeof(Elf32_Shdr) *ehdr->e_shnum);
   assert(shdr != NULL);

   readSection(f, ehdr, shdr);


//-------------------------Etape 2---------------------------------
  //recup du tableau des noms de sections
  int t = shdr[ehdr->e_shstrndx].sh_size;
  char *nom = malloc(t);
  assert(nom != NULL);

  //printf("type tab noms:%x\n", shdr[ehdr->e_shstrndx].sh_offset);

  fseek(f, shdr[ehdr->e_shstrndx].sh_offset, SEEK_SET);
  fread(nom, t, 1, f);

//----------------+Etape 3+-------//recup du nom de section et de son indice------------------------
if(c == 3){
 section = argv[2];
 v = atoi(section);

 if(v > 0 && v < ehdr->e_shnum){ //alors s est le num de la section
  ind = v;
  nomS = nom+shdr[v].sh_name;
 }
 else{   //s est le nom de la section
  i=0;
  while (i < ehdr->e_shnum && strcmp(section, nom+shdr[i].sh_name)) {
    i++;
  }
  if(i == ehdr->e_shnum && c==3){
    printf("nom de section invalide!\n");
    ind = 0;
    nomS = "";
    //exit(3);
  }
  else{
    nomS = section;
    ind = i;
  }
}

}

 //-------Etape 4:--creation table de symboles--------------------------------------------------------------
   //recherche de l'indice de ".symtab" dans la table des sections
   int iSym; //indice de .SYMTAB
   int taille; //taille de la table de symboles
   i = 0;
   while(i < ehdr->e_shnum  &&  shdr[i].sh_type != 2){
     i++;
   }
   if(i == ehdr->e_shnum){
     printf("indice de « .symtab » non trouvé!\n");
     iSym = 0;
     //exit(4);
   }
   else{
     iSym = i;
   }

   //--------------copie des NOMs de Symboles-----------------------------
   //recherche de l'indice de ".strtab" dans la table des sections
   int id; //indice de .STRTAB
   i = 0;
    while (i < ehdr->e_shnum && strcmp(".strtab", nom+shdr[i].sh_name)) {
     i++;
   }
   if(i == ehdr->e_shnum){
     printf("indice de « .strtab » non trouvé!\n");
     id = 0;
     //exit(4);
   }
   else{
     id = i; //printf("%d\t", id);
   }

     int k = shdr[id].sh_size;
     nomSym  = malloc(k);
     assert(nomSym != NULL);
     fseek(f, shdr[id].sh_offset, SEEK_SET);
     fread(nomSym, k, 1, f);
     //printf("%s\n", nom+shdr[sym].sh_name);


   taille = shdr[iSym].sh_size / shdr[iSym].sh_entsize;
   symb = malloc(sizeof(Elf32_Sym) * taille);
   assert(symb != NULL);
   //test(taille);
   readSymbole(f, ehdr, shdr, symb, iSym);

   //----------------------------------------------------------

//------------------------------------------------------------------------------------
   switch(c){
     case 1:
      printHeader(ehdr);
      break;
     case 2:
      //printf("affichage de la table de section\n");
      printSection(f, ehdr, shdr, nom);
      break;
     case 3:
      //printf("affichage du contenu de la section %s:\n", argv[2]);
      contenuS(f, ehdr, shdr, ind, nomS);
      printf("\n");
      break;
     case 4:
      printf("Table de symboles « .symtab » contient %d entrées:\n", taille);
      printSymbole(f, ehdr, shdr, symb, iSym, nomSym);
      break;
     case 5:
      //printf("Tables de réimplantation:\n");
      reloc(f, ehdr, shdr, symb, nom, nomSym);
      break;
     case 6:
      printHeader(ehdr);
      //printf("affichage de la table de section\n");
      printSection(f, ehdr, shdr, nom);
      reloc(f, ehdr, shdr, symb, nom, nomSym);
      printf("Table de symboles « .symtab » contient %d entrées:\n", taille);
      printSymbole(f, ehdr, shdr, symb, iSym, nomSym);
      break;
     default:
      break;
  }



  fclose(f);
  free(nom);
  free(ehdr);
  free(shdr);
  free(symb);
  free(nomSym);

  return 0;
}
